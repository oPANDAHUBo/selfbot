def gbp_to_usd(value_gbp):
    conversion_rate = 1.25
    converted = value_gbp * conversion_rate
    return converted
 
value_gbp = 5
converted_usd = gbp_to_usd(value_gbp)
print(f"Converted £{value_gbp} to ${converted_usd}!")