import time

def parse_time(time_str):
    time_units = {
        's': 1,
        'm': 60,
        'h': 3600,
        'd': 86400
    }
    try:
        num = int(time_str[:-1])
        unit = time_str[-1].lower()
        return num * time_units[unit]
    except:
        return None
        
def remind(msg, time_str):
    time_seconds = parse_time(time_str)
    if time_seconds is None:
        print("Invalid time format. Please use a number followed by 's', 'm', 'h', or 'd'.")
        return
    

    time.sleep(time_seconds)
    print("# Reminder:\n", msg)
