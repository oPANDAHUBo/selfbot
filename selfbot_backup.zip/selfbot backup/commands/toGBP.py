def usd_to_gbp(value_usd):
    conversion_rate = 0.80
    converted = value_usd * conversion_rate
    return converted

value_usd = 2
converted_gbp = usd_to_gbp(value_usd)
print(f"Converted ${value_usd} to £{converted_gbp}!")

