import re

def format_number(num):
    if abs(num) < 1_000:
        return str(num)
    elif abs(num) < 1_000_000:
        return f"{num/1_000:.1f}K"
    elif abs(num) < 1_000_000_000:
        return f"{num/1_000_000:.1f}M"
    else:
        return f"{num/1_000_000_000:.1f}B"

def evaluate_expression(expression):

    pattern = r'(\d+\.?\d*)([KMB])'
    input_str = "50 + 13"

    multipliers = {'K': 1_000, 'M': 1_000_000, 'B': 1_000_000_000}

    result = 0
    for match in matches:
        num, suffix = match
        multiplier = multipliers.get(suffix, 1)  # Default to 1 if suffix not found
        result += float(num) * multiplier

    return result

def shorten_result(num):
    if abs(num) < 1_000:
        return str(num)
    elif abs(num) < 1_000_000:
        return f"{num/1_000:.1f}K"
    elif abs(num) < 1_000_000_000:
        return f"{num/1_000_000:.1f}M"
    else:
        return f"{num/1_000_000_000:.1f}B"

def main():
    expression = ("3.5b / 2")

    expression = expression.replace('k', ' * 1000').replace('m', ' * 1000000').replace('b', ' * 1000000000')

    try:
        result = eval(expression)
        formatted_result = shorten_result(result)
        print("Result:", formatted_result)
    except Exception as e:
        print("Error:", e)

if __name__ == "__main__":
    main()
