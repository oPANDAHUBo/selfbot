import re
import requests
url = 'https://sky.shiiyu.moe/api/v2/profile/'
def fetch_net_worth(username):
    try:
        response = requests.get(url + username)
        response.raise_for_status()
        data = response.text
        net_worth = re.search(r'"unsoulboundNetworth":(\d+)', data)
        if net_worth:
            formatted_net_worth = format_number(int(net_worth.group(1)))
            return formatted_net_worth
        else:
            raise ValueError('unsoulboundNetworth not found in data')
    except Exception as e:
        raise e
def format_number(number):
    suffixes = ['', 'K', 'M', 'B']
    suffix_index = int(len(str(number)) / 3)
    short_number = number / (1000 ** suffix_index)
    rounded_number = round(short_number, 2)
    formatted_number = f"{rounded_number}{suffixes[suffix_index]}"
    return formatted_number
if __name__ == "__main__":
    username = "ooopbl"
    try:
        net_worth = fetch_net_worth(username)
        print(f"Networth for user {username} is: **", net_worth, "**")
    except Exception as e:
        print(f"Error: {e}")
