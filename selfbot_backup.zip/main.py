import subprocess
import asyncio
import os
import requests
import random
import geocoder
import discord
import time
import io
import aiohttp
from discord import Embed
from discord.ext import commands, tasks
from datetime import timedelta
import re

sent_messages = set()




client = commands.Bot(command_prefix='.', self_bot=True)
bot_js_running = False
os.system('cls')
print("Started selfbotbot!")


            
counter_value = 0

tasks_dict = {}

def parse_time(time_str):
    time_regex = re.compile(r'(\d+)([smhd])')
    matches = time_regex.findall(time_str)
    if not matches:
        return None
    time_kwargs = {}
    for value, unit in matches:
        if unit == 's':
            time_kwargs['seconds'] = int(value)
        elif unit == 'm':
            time_kwargs['minutes'] = int(value)
        elif unit == 'h':
            time_kwargs['hours'] = int(value)
        elif unit == 'd':
            time_kwargs['days'] = int(value)
    return timedelta(**time_kwargs)

def create_repeated_task(channel, message, delay):
    @tasks.loop(seconds=delay.total_seconds())
    async def repeated_task():
        await channel.send(message)

    return repeated_task

@client.command()
async def ad(ctx, delay: str, channel_link: str, *, message: str):
    delay_timedelta = parse_time(delay)
    if not delay_timedelta:
        await ctx.send("Invalid time format! Use s (seconds), m (minutes), h (hours), d (days).")
        return
    
    channel_id_match = re.search(r'(\d{17,19})', channel_link)
    if not channel_id_match:
        await ctx.send("Invalid channel link! Make sure to provide a valid channel link.")
        return

    channel_id = int(channel_id_match.group(1))
    channel = client.get_channel(channel_id)
    
    if not channel:
        await ctx.send(f"Channel not found! Make sure the bot has access to the channel. Channel ID: {channel_id}")
        return

    if channel_id in tasks_dict:
        tasks_dict[channel_id].cancel()
    
    task = create_repeated_task(channel, message, delay_timedelta)
    tasks_dict[channel_id] = task
    task.start()
    await ctx.send(f"Repeating message every {delay} in <#{channel_id}>: {message}")

@client.command()
async def check(ctx, ipcheck: str):
    await ctx.send("checking...")
    ping = os.system("ping " + ipcheck)
    if ping == 0:
        await ctx.send("IP is currently online")
        os.system('cls')
    else:
        await ctx.send("IP is currently offline")
        os.system('cls')

@client.command()
async def nw(ctx, ign: str):
    await ctx.send(f"Checking Networth for user {ign} ")
    try:
        folder_path = os.path.join(os.getcwd(), 'commands')
        nw_Path = os.path.join(folder_path, 'networth.py')
        with open(nw_Path, 'r') as file:
            data = file.readlines()
        data[24] = f'    username = "{ign}"\n'
        with open(nw_Path, 'w') as file:
            file.writelines(data)
        result = subprocess.run(['py', nw_Path], capture_output=True, text=True, check=True)
        output = result.stdout.strip()
        if output == "Unsoulbound net worth: 1.46K":
            await ctx.send("User does not exist.")
        else:
            await ctx.send(f"{output}")
    except subprocess.CalledProcessError as e:
        return None

@client.command()
async def toGBP(ctx, usdamount: int):
    try:
        folder_path = os.path.join(os.getcwd(), 'commands')
        GBP_Path = os.path.join(folder_path, 'toGBP.py')
        with open(GBP_Path, 'r') as file:
            data = file.readlines()
        data[5] = f"value_usd = {usdamount}\n"
        with open(GBP_Path, 'w') as file:
            file.writelines(data)
        result = subprocess.run(['py', GBP_Path], capture_output=True, text=True, check=True)
        output = result.stdout.strip()
        await ctx.send(output)
    except subprocess.CalledProcessError as e:
        return None

@client.command()
async def toUSD(ctx, gbpamount: int):
    try:
        folder_path = os.path.join(os.getcwd(), 'commands')
        USD_Path = os.path.join(folder_path, 'toUSD.py')
        with open(USD_Path, 'r') as file:
            data = file.readlines()
        data[5] = f"value_gbp = {gbpamount}\n"
        with open(USD_Path, 'w') as file:
            file.writelines(data)
        result = subprocess.run(['py', USD_Path], capture_output=True, text=True, check=True)
        output = result.stdout.strip()
        await ctx.send(output)
    except subprocess.CalledProcessError as e:
        return None

@client.command()
async def spam(ctx, amount: int, *, message6: str):
    async def send_message(msg, loops):
        try:
            for _ in range(loops):
                await ctx.send(msg)
        except discord.errors.HTTPException:
            await ctx.send("Rate limited")
    loops = amount
    await send_message(message6, loops)

@client.command()
async def flip(ctx):
    def flip_coin():
        result = random.choice(["Heads", "Tails"])
        return result
    result = flip_coin()
    await ctx.send(f"The coin landed on: **{result}**")

@client.command()
async def remind(ctx, delay: str, *, message1: str):
    await ctx.send("reminder set!")
    try:
        folder_path = os.path.join(os.getcwd(), 'commands')
        remind_Path = os.path.join(folder_path, 'remind.py')
        with open(remind_Path, 'r') as file:
            data = file.readlines()
        data[25] = f'msg = "**{message1}**"\n'
        data[26] = f'time_str = "{delay}"\n'
        with open(remind_Path, 'w') as file:
            file.writelines(data)
        result = subprocess.run(['py', remind_Path], capture_output=True, text=True, check=True)
        output = result.stdout.strip()
        await ctx.send(output)
        await ctx.send(ctx.author.mention)
        await ctx.send(ctx.author.mention)
        await ctx.send(ctx.author.mention)
        await ctx.send(ctx.author.mention)
        await ctx.send(ctx.author.mention)
    except subprocess.CalledProcessError as e:
        return None

@client.command()
async def calc(ctx, *, problem: str):
    try:
        folder_path = os.path.join(os.getcwd(), 'commands')
        calc_Path = os.path.join(folder_path, 'calculator.py')

        with open(calc_Path, 'r') as file:
            data = file.readlines()

        data[38] = f'    expression = ("{problem}")\n'

        with open(calc_Path, 'w') as file:
            file.writelines(data)

        result = subprocess.run(['py', calc_Path], capture_output=True, text=True, check=True)
        output = result.stdout.strip()
        await ctx.send(output)

    except subprocess.CalledProcessError as e:
        return None

@client.command()
async def who(ctx):
    await ctx.message.delete()
    await ctx.send("""
Ah, here we go again—another unsolicited opinion making its grand entrance into the conversation. How quaint. It's like a surprise visit from that one relative who always overstays their welcome. But fear not, for in the grand tradition of social etiquette, we have a little phrase for moments like these: "who asked?"

Yes, my dear pontificator, before you continue to grace us with your pearls of wisdom, allow me to enlighten you: nobody asked. Nobody sent out a distress signal begging for your input, nor did they post a classified ad seeking out your hot takes. And yet, here you are, ready to regale us with your unfiltered thoughts as if they were precious nuggets of gold.

But let's not dwell on the negative, shall we? Instead, let's take a moment to appreciate the sheer audacity of it all. You, dear interjector, are like a superhero with a knack for crashing parties uninvited. Your ability to inject yourself into any conversation, no matter how irrelevant, is truly awe-inspiring.

So, as we navigate this delicate dance of social interaction, let us remember the immortal words: "who asked?" They serve as a gentle reminder that not every thought needs to be shared, not every opinion needs to be voiced. So, unless you've been specifically summoned like a genie from a bottle, kindly keep your musings to yourself and let the rest of us enjoy the sweet serenade of silence.
""")

@client.command()
async def purge(ctx, amountpurge: int):
    messages = await ctx.channel.history(limit=amountpurge + 1).flatten()  # Fetch the last amountpurge + 1 messages
    for message in messages:
        if message.author == client.user:
            await message.delete()

@client.command()
async def counter(ctx, action: str, amount: int):
    await ctx.message.delete()
    global counter_value
    if action == '+':
        counter_value += amount
    elif action == '-':
        counter_value -= amount

    await ctx.send(f"Counter: {counter_value}")

@client.command()
async def product(ctx, *, args: str):
    await ctx.message.delete()
    try:
        lines = args.split('\n')
        PTitle = lines[0]
        message_link = '\n'.join(lines[1:])
        embed = discord.Embed(
            title=PTitle,
            description=message_link,
            color=0x00ff00
        )
        with open("embedlogo.png", "rb") as avatar_file:
            avatar_bytes = avatar_file.read()

        webhook = await ctx.channel.create_webhook(name="Master Coins", avatar=avatar_bytes)

        await webhook.send(embed=embed)

        await webhook.delete()
    except Exception as e:
        await ctx.send(f"Error: {e}")

@client.command()
async def anypurge(ctx, amount: int):
    try:
        if amount <= 0:
            await ctx.send("Please specify a positive number of messages to delete.")
            return
        deleted_messages = await ctx.channel.purge(limit=amount)
    except Exception as e:
        await ctx.send(f"Error: {e}")

@client.command()
async def cmds(ctx):
    try:
        help_message = (
            "# .product\n"
            "**Usage:** `.product (Title) new line (product info)`\n"
            "Creates an embed with the provided title and info.\n\n"

            "# .anypurge\n"
            "**Usage:** `.anypurge (amount to delete)`\n"
            "Deletes the specified number of messages from anyone in the channel.\n"

            "# .purge\n"
            "**Usage:** `.purge (amount to delete)`\n"
            "Deletes the specified number of messages from you in the channel.\n"

            "# .who\n"
            "**Usage:** `.who`\n"
            "sends a long message saying no one asked\n"

            "# .calc\n"
            "**Usage:** `.calc num1 +-x/ num2`\n"
            "calculates your numbers (+, -, x, /)\n"

            "# .remind\n"
            "**Usage:** `.remind 10h msg`\n"
            "reminds you to do whatever\n"

            "# .flip\n"
            "**Usage:** `.flip`\n"
            "flips a coin heads or tails\n"

            "# .spam\n"
            "**Usage:** `.spam amount message`\n"
            "spams messages in your current channel\n"

            "# .toUSD\n"
            "**Usage:** `.toUSD GBP amount`\n"
            "converts GBP to USD\n"

            "# .toGBP\n"
            "**Usage:** `.toGBP USD amount`\n"
            "converts USD to GBP\n"

            "# .nw\n"
            "**Usage:** `.nw username`\n"
            "gets the unsoulbound networth of a user\n"

            "# .check\n"
            "**Usage:** `.check ip`\n"
            "checks if a IP is responding\n"

            "# .ad\n"
            "**Usage:** .ad delay channelID message\n"
            "repeats a message to the channel"

        )

        await ctx.send(help_message)
    except Exception as e:
        await ctx.send(f"Error: {e}")

client.run('', bot=False)